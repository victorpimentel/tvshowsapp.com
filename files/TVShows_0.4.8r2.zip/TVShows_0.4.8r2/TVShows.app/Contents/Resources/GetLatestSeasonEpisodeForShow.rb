#!/usr/bin/env ruby

# This file is part of the TVShows source code.
# http://github.com/mattprice/TVShows

# TVShows is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

require File.join(File.dirname(__FILE__), 'TVShowsScript/lib/simple-rss.rb')
require 'open-uri'

begin
	url = ARGV[0]
	begin
		episodes = SimpleRSS.parse(open(url))
	rescue => exception
		exit(-1)
	end
	
	maxSeason = 0
	maxEpisode = 0
	episodes.items.each do |episode|
		seasonNoMatch = /Season\s*:\ ([0-9]*?);/.match(episode.description)
		if ( !seasonNoMatch.nil? ) then
			seasonNo = seasonNoMatch[1].to_i
			episodeNoMatch = /Episode\s*:\ ([0-9]*?)$/.match(episode.description)
			if ( !episodeNoMatch.nil? ) then
				episodeNo = episodeNoMatch[1].to_i
				if ( (maxSeason == seasonNo and maxEpisode < episodeNo) or (maxSeason < seasonNo) ) then
					maxSeason = seasonNo
					maxEpisode = episodeNo
				end
			end
		end
	end

	print "#{maxSeason}-#{maxEpisode}"

	exit(0)
rescue
	exit(-1)
end
